# Week-04 การให้นิยามวัตถุและ UML Diagram (2)

## หัวข้อที่จะเรียนรู้

### 4.1 Generalization Abstraction

#### 4.1.1 หลักการของ Generalization Abstraction

#### 4.1.2 หลักการของ Specialization Abstraction

#### 4.1.3 กฏเกณฑ์และกลไกของ Inheritance

#### 4.1.4 กฏเกณฑ์และกลไกของ Polymorphism

#### 4.1.5 การปฏิบัติการทดลอง  การวาดแบบจำลอง Generalization Abstraction ด้วยโปรแกรม plantUML

###  4.2 Association Abstraction

#### 4.2.1 หลักการของ Association Abstraction

#### 4.2.2 การกำหนด Cardinality, Required และ Optional Components  ของวัตถุ

### [4.3 การปฏิบัติการทดลอง การวาดแบบจำลอง Generalization และ Association ด้วยโปรแกรม plantUML](./Week04-lab-part-01.md)

